module.exports={
    status_200: "Successfuly",
    status_201: "Created",
    status_400: "Bad Request",
    status_401: "Unauthorized",
    status_404: "Not Fount",
    status_500: "Inernal Server Error",
    status_402: "Servie Unavilable",
}