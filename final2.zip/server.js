const Fastify = require("fastify");
const fastify = Fastify({ logger: true });

const Next = require("next");
const app = Next({ dev: process.env.NODE_ENV !== "production" });
const handle = app.getRequestHandler();

const product_router = require("./api/modules/product_data/router");


app
  .prepare()
  .then(async () => {
    fastify.addHook("preHandler", (request, reply, done) => {
      console.log("Content-Type:", request.headers["content-type"]);
      done();
    });

    fastify.register(product_router, { prefix: "/api/module/product" });
    
    fastify.all("/*", (req, reply) => {
      return handle(req.raw, reply.raw)
        .then(() => {
          reply.sent = true;
        })
        .catch((err) => {
          console.error("Error handling request:", err);
          reply.code(500).send("Internal Server Error");
        });
    });






















    fastify
      .listen({ port: 7000, host: "0.0.0.0" })
      .then((address) => {
        console.log(`> Ready on ${address}`);
      })
      .catch((error) => {
        console.error(error);
        process.exit(1);
      });
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });