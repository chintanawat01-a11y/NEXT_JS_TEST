
"use client";
import Button from "../../../COMPONENT/object/button.jsx";

export default function ProductTable({items, onEdit, onDelete}){
  return (
    <div className="card">
      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Created</th>
            <th style={{textAlign:'right'}}>Action</th>
          </tr>
        </thead>
        <tbody>
          {items?.length ? items.map((p)=> (
            <tr key={p.id}>
              <td><span className="badge">{p.id}</span></td>
              <td>{p.product_name}</td>
              <td>{p.category || "-"}</td>
              <td>{Number(p.price ?? 0).toLocaleString()}</td>
              <td>{p.stock}</td>
              <td>{p.created ? String(p.created).slice(0,10) : "-"}</td>
              <td>
                <div className="actions">
                  <Button onClick={()=>onEdit(p)}>แก้ไข</Button>
                  <Button variant="danger" onClick={()=>onDelete(p)}>ลบ</Button>
                </div>
              </td>
            </tr>
          )) : (
            <tr><td colSpan={7} style={{textAlign:'center',color:'#9aa0a6'}}>No data</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
