
"use client";
import React from "react";
import SearchInput from "../../component/object/search-input.jsx";
import Button from "../../component/object/button.jsx";
import ProductTable from "../../component/page/product_data/table-full.jsx";
import ProductForm from "../../component/page/product_data/product-form.jsx";
import api_handler from "../../hooks/api-handler.js";
import { reducer, initialState } from "./reducer.jsx";

export default function ProductDataPage(){
  const [state, dispatch] = React.useReducer(reducer, initialState);
  const [loading, setLoading] = React.useState(false);
  const list = React.useMemo(()=>{
    if (!state.query) return state.list;
    const q = state.query.toLowerCase();
    return state.list.filter(p => 
      p.id?.toLowerCase().includes(q) || 
      p.product_name?.toLowerCase().includes(q) ||
      p.category?.toLowerCase().includes(q)
    );
  }, [state.list, state.query]);

  async function load(){
    setLoading(true);
    try{
      const res = await api_handler("get", "/api/module/product/", {});
      const data = res?.data?.results ?? [];
      dispatch({ type: "set-list", payload: data });
    } finally { setLoading(false); }
  }
  React.useEffect(()=>{ load(); }, []);

  async function handleCreate(form){
    const payloadArr = [
      form.store_id || "",
      form.product_name || "",
      form.product_detail || null,
      form.product_price ? Number(form.product_price) : null,
      form.product_date || null,
      form.product_category || null,
      form.product_stock ? Number(form.product_stock) : null,
      form.product_url_img || null
    ];
    await api_handler("post", "/api/module/product/", { body: payloadArr });
    dispatch({ type: "close-form" });
    await load();
  }

  async function handleEditSave(form, item){
    const body = {
      product_name: form.product_name,
      product_detail: form.product_detail ?? null,
      product_price: form.product_price ? Number(form.product_price) : null,
      product_date: form.product_date ?? null,
      product_category: form.product_category ?? null,
      product_stock: form.product_stock ? Number(form.product_stock) : null,
      product_url_img: form.product_url_img ?? null,
    };
    await api_handler("put", `/api/module/product/${item.id}`, { body });
    dispatch({ type: "close-form" });
    await load();
  }

  async function handleDelete(item){
    if (!confirm(`ลบสินค้า ${item.product_name}?`)) return;
    await api_handler("delete", `/api/module/product/${item.id}`);
    await load();
  }

  return (
    <div className="grid">
      <div className="space-between">
        <h2 style={{margin:0}}>Products</h2>
        <div className="row" style={{minWidth: 360}}>
          <SearchInput value={state.query} onChange={(v)=>dispatch({type:"set-query", payload:v})} placeholder="พิมพ์เพื่อค้นหา..." />
          <Button variant="primary" onClick={()=>dispatch({type:"open-create"})}>เพิ่มสินค้า</Button>
        </div>
      </div>

      {state.showForm && (
        <ProductForm
          initial={state.editing}
          onCancel={()=>dispatch({type:"close-form"})}
          onSubmit={(form)=> state.editing ? handleEditSave(form, state.editing) : handleCreate(form)}
        />
      )}

      {loading ? (
        <div className="card">กำลังโหลด...</div>
      ) : (
        <ProductTable
          items={list}
          onEdit={(item)=>dispatch({type:"open-edit", payload:item})}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
}

