export default function ProductDataLayout({ children }){
  return <>{children}</>;
}
