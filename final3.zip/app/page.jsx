
export default function Home() {
  return (
    <div className="card">
      <h1 style={{margin:0}}>ยินดีต้อนรับ</h1>
      <p className="mt-3">ดูรายการสินค้าได้ที่เมนู <a className="badge" href="/product_data">/product_data</a></p>
    </div>
  );
}
