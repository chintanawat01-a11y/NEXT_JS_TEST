
"use client";
import React from "react";
import SearchInput from "../../component/object/search-input.jsx";
import Button from "../../component/object/button.jsx";
import ProductTable from "../../component/page/product_data/table-full.jsx";
import ProductForm from "../../component/page/product_data/product-form.jsx";
import api_handler from "../../hooks/api-handler.js";
import { reducer, initialState } from "./reducer.jsx";

export default function ProductDataPage(){
  const [state, dispatch] = React.useReducer(reducer, initialState);
  const [loading, setLoading] = React.useState(false);
  const list = React.useMemo(()=>{
    if (!state.query) return state.list;
    const q = state.query.toLowerCase();
    return state.list.filter(p => 
      p.id?.toLowerCase().includes(q) || 
      p.product_name?.toLowerCase().includes(q) ||
      p.category?.toLowerCase().includes(q)
    );
  }, [state.list, state.query]);

  async function load(){
    setLoading(true);
    try{
      const res = await api_handler("get", "/api/module/product/", {});
      const data = res?.data?.results ?? [];
      dispatch({ type: "set-list", payload: data });
    } finally { setLoading(false); }
  }
  React.useEffect(()=>{ load(); }, []);

async function handleCreate(form){
  // validate เบื้องต้น
  const price = Number(form.product_price);
  const stock = Number(form.product_stock);
  if (!form.store_id?.trim()) return alert("กรอก Store ID");
  if (!form.product_name?.trim()) return alert("กรอกชื่อสินค้า");
  if (!Number.isFinite(price) || price <= 0) return alert("ราคา > 0 เท่านั้น");
  if (!Number.isFinite(stock) || stock < 0) return alert("สต็อกต้อง ≥ 0");

  // ประกอบ payload เป็น "อาเรย์ 8 ช่อง"
  const payload = [
    form.store_id,
    form.product_name,
    form.product_detail || null,
    price,
    form.product_date || null,           // ต้องเป็น YYYY-MM-DD ถ้าส่งมา
    form.product_category || null,
    stock,
    form.product_url_img || null,
  ];
 console.log("payload", payload);
  // ส่งเป็นอาเรย์ตรง ๆ
  await api_handler("post", "/api/module/product/", {body: payload});
  dispatch({ type: "close-form" });
  await load();
}



// app/product_data/page.jsx
async function handleEditSave(form, item){
  const keep = [
    "product_name",
    "product_detail",
    "product_price",
    "product_date",      // รูปแบบ YYYY-MM-DD
    "product_category",
    "product_stock",
    "product_url_img",
  ];

  const body = {};
  for (const k of keep) {
    let v = form[k];
    if (v === "" || v === undefined || v === null) continue; // ไม่ส่งคีย์ว่าง
    if (k === "product_price" || k === "product_stock") {
      v = Number(v);
      if (Number.isNaN(v)) continue; // กัน NaN
    }
    if (k === "product_date") {
      // ถ้าไม่ตรง yyyy-mm-dd ให้ตัดทิ้ง (จะไม่อัปเดตฟิลด์นี้)
      if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v))) continue;
    }
    body[k] = v;
  }

  try {
    await api_handler("put", `/api/module/product/${item.id}`, { body });
    dispatch({ type: "close-form" });
    await load();
  } catch (e) {
    const msg = e?.response?.data?.error || e?.message || "Update failed";
    alert(`อัปเดตไม่สำเร็จ: ${msg}`);
  }
}


  async function handleDelete(item){
    if (!confirm(`ลบสินค้า ${item.product_name}?`)) return;
    await api_handler("delete", `/api/module/product/${item.id}`);
    await load();
  }

  return (
    <div className="grid">
      <div className="space-between">
        <h2 style={{margin:0}}>Products</h2>
        <div className="row" style={{minWidth: 360}}>
          <SearchInput value={state.query} onChange={(v)=>dispatch({type:"set-query", payload:v})} placeholder="พิมพ์เพื่อค้นหา..." />
          <Button variant="primary" onClick={()=>dispatch({type:"open-create"})}>เพิ่มสินค้า</Button>
        </div>
      </div>

      {state.showForm && (
        <ProductForm
          initial={state.editing}
          onCancel={()=>dispatch({type:"close-form"})}
          onSubmit={(form)=> state.editing ? handleEditSave(form, state.editing) : handleCreate(form)}
        />
      )}

      {loading ? (
        <div className="card">กำลังโหลด...</div>
      ) : (
        <ProductTable
          items={list}
          onEdit={(item)=>dispatch({type:"open-edit", payload:item})}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
}

